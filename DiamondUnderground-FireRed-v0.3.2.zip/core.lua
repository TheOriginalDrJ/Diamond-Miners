-- All durable Underground data lives in session.meta and uses JSON-safe keys.
local U={MAP='FR_DIAMOND_UNDERGROUND',VERSION=2}
U.dirs={up={0,-1},right={1,0},down={0,1},left={-1,0}}
U.colors={'red','blue','green','prism','pale'}
function U.new(mod)
  local self={mod=mod}
  setmetatable(self,{__index=U})
  for _,name in ipairs({'map','mining_objects','goods'}) do self[name]=assert(loadstring(assert(mod:read('assets/'..name..'.lua'))))() end
  self.collision=assert(mod:read('assets/collision.bin'))
  self.regions=self:regionsBuild()
  self.vendors={}
  local places={goods={{72,104},{424,87},{200,185},{335,264},{175,279},{424,439},{87,456},{311,358}},fossils={{232,87},{328,151},{232,215},{232,298},{279,328},{279,456},{183,392},{279,245}},treasures={{40,471},{471,72},{471,471},{40,72}}}
  for kind,rows in pairs(places) do for _,p in ipairs(rows) do
    local x,y=self:nearest(p[1],p[2]);self.vendors[#self.vendors+1]={x=x,y=y,kind=kind}
  end end
  return self
end
function U:key(x,y) return x..','..y end
function U:returnLocation(game)
  local function valid(p)
    return type(p)=='table' and type(p.map)=='string' and p.map:match('^FR_')
      and p.map~=self.MAP and type(p.x)=='number' and type(p.y)=='number'
  end
  if valid(self.s.returnLocation)then return self.s.returnLocation end
  -- 0.2.0 discarded custom metadata during its quick-save, but an in-progress
  -- trip can still recover its departure from that surface save snapshot.
  local saved=game and game.save
  local old=saved and saved.meta and saved.meta.diamondUnderground
  local source=old and old.returnLocation
  if not valid(source)then source=saved end
  if valid(source)then
    self.s.returnLocation={map=source.map,x=source.x,y=source.y,facing=source.facing or 'down'}
    return self.s.returnLocation
  end
  return nil
end
function U:open(x,y)
  return x>=0 and y>=0 and x<self.map.width and y<self.map.height and self.collision:byte(y*self.map.width+x+1)==1
end
function U:nearest(x,y)
  for r=0,64 do for dy=-r,r do for dx=-r,r do if self:open(x+dx,y+dy) then return x+dx,y+dy end end end end
  error('No Underground floor near entry')
end
function U:regionsBuild()
  local seen,regions={},{}
  local w,h=self.map.width,self.map.height
  for y=0,h-1 do for x=0,w-1 do
    local k=y*w+x
    if not seen[k] and self:open(x,y) then
      local q={{x,y}};seen[k]=true;local i=1
      while i<=#q do local p=q[i];i=i+1
        for _,d in pairs(U.dirs) do local nx,ny=p[1]+d[1],p[2]+d[2];local nk=ny*w+nx
          if not seen[nk] and self:open(nx,ny) then seen[nk]=true;q[#q+1]={nx,ny} end
        end
      end
      if #q>500 then regions[#regions+1]={size=#q,x=q[math.floor(#q/2)][1],y=q[math.floor(#q/2)][2]} end
    end
  end end
  table.sort(regions,function(a,b)return a.size>b.size end)
  return regions
end
function U:state(session)
  session.meta=session.meta or {}
  local s=session.meta.diamondUnderground
  if not s then
    local r=self.regions[1]
    s={version=2,x=r.x,y=r.y,facing='down',region=1,seed=193547,seconds=0,steps=0,
      spheres={},treasures={},goods={['7']=1,['8']=1,['9']=1},
      buried={},spots={},depleted={},drills=1,
      records={excavations=0,recovered=0,spheres=0},intro=false}
    session.meta.diamondUnderground=s
  end
  -- Migrate old saves: traps no longer exist in the Underground.
  s.traps=nil;s.placedTraps=nil;s.naturalTraps=nil;s.records.traps=nil;s.version=2
  s.zoomOut=math.max(1,math.min(10,math.floor(tonumber(s.zoomOut) or 1)))
  self.s=s
  return s
end
function U:random(n)
  local s=self.s;s.seed=(s.seed*48271)%2147483647
  return math.floor(s.seed/2147483647*n)+1
end
function U:front()
  local s=self.s;local d=U.dirs[s.facing];return s.x+d[1],s.y+d[2]
end
function U:blocked(x,y)
  local s=self.s
  if s.inBase then
    if x<10 or x>21 or y<10 or y>21 then return true end
    if (x==15 or x==16) and y==12 then return true end
    for _,p in ipairs(s.base.boulders or {})do if x>=p.x and x<p.x+2 and y>=p.y and y<p.y+2 then return true end end
    for _,p in ipairs(s.base.decorations) do local g=self.goods[p.id]
      if x>=p.x and y>=p.y and x<p.x+g.width and y<p.y+g.depth then return true end
    end
    return false
  end
  if not self:open(x,y) then return true end
  for _,v in ipairs(self.vendors) do if v.x==x and v.y==y then return true end end
  return false
end
function U:seedSpots()
  local s=self.s;if s.inBase then return end
  local count=0;for _,p in pairs(s.spots) do if math.abs(p.x-s.x)<40 and math.abs(p.y-s.y)<40 then count=count+1 end end
  if count>=10 then return end
  for attempt=1,500 do
    local x=s.x+self:random(49)-25;local y=s.y+self:random(49)-25
    if not self:open(x,y) and x>32 and y>32 and x<480 and y<480 then
      local adjacent=false
      for _,d in pairs(U.dirs) do if self:open(x+d[1],y+d[2]) then adjacent=true end end
      local key=self:key(x,y)
      if adjacent and not s.spots[key] and (not s.depleted[key] or s.steps-s.depleted[key]>250) then
        s.spots[key]={x=x,y=y};count=count+1;if count>=14 then break end
      end
    end
  end
  -- Bound persistent world caches during very long exploring sessions.
  local n=0;for _ in pairs(s.spots)do n=n+1 end
  if n>250 then for k,p in pairs(s.spots)do if math.abs(p.x-s.x)>50 or math.abs(p.y-s.y)>50 then s.spots[k]=nil;n=n-1;if n<=250 then break end end end end

end
function U:addSphere(color,size)
  local s=self.s;if #s.spheres>=40 then return false,'Your Sphere pocket is full (40). Bury or trade a sphere first.' end
  s.spheres[#s.spheres+1]={color=color,size=math.min(99,size)};return true
end
function U:bury(index)
  local s=self.s;local item=s.spheres[index];if not item then return false end
  if s.inBase then return false,'Spheres cannot be buried inside a Secret Base.' end
  local key=self:key(s.x,s.y);local old=s.buried[key]
  if old and old.color~=item.color then return false,'A different sphere is already buried here.' end
  if old then
    local large,small=math.max(old.size,item.size),math.min(old.size,item.size)
    old.size=math.min(99,large+math.floor(small/5)+1);old.time=os.time()
  else s.buried[key]={x=s.x,y=s.y,color=item.color,size=item.size,time=os.time()} end
  table.remove(s.spheres,index);return true,'Sphere buried. Return later to collect it; same-color spheres combine.'
end
function U:unbury(key)
  local s=self.s;local p=s.buried[key];if not p then return false end
  local days=math.max(0,math.floor((os.time()-p.time)/86400));local rates={red=3,blue=3,green=3,prism=1,pale=1}
  local size=math.min(99,p.size+days*(rates[p.color] or 1))
  local ok,msg=self:addSphere(p.color,size)
  if ok then s.buried[key]=nil;s.records.spheres=s.records.spheres+1;return true,p.color..' Sphere, size '..size..', recovered!' end
  return false,msg
end
function U:pay(color,size)
  local best
  for i,p in ipairs(self.s.spheres) do if p.color==color and p.size>=size and (not best or p.size<self.s.spheres[best].size) then best=i end end
  if not best then return false end
  table.remove(self.s.spheres,best);return true
end
function U:newMine()
  local m={layers={},objects={},occupied={},integrity=196,tool='pick',x=6,y=4,hits=0,found=0,complete=false}
  for i=1,130 do m.layers[i]=2 end
  local patch4={'00444400','04444440','44444400','44444400','44444400','44444400','04444440','00444400'}
  local patch6={'06660','66666','66666','66666','06660'}
  for pass=1,2 do local patch=pass==1 and patch4 or patch6;local size=#patch
    for _=1,pass==1 and 10 or 15 do
      local sx=self:random(13+size)-1-size;local sy=self:random(10+size)-1-(pass==1 and 5 or size);local can=true
      if pass==2 then for dy=0,size-1 do for dx=0,size-1 do local x,y=sx+dx,sy+dy
        if x>=0 and x<13 and y>=0 and y<10 and patch[dy+1]:sub(dx+1,dx+1)~='0' and m.layers[y*13+x+1]<4 then can=false end
      end end end
      if can then for dy=0,size-1 do for dx=0,size-1 do local x,y=sx+dx,sy+dy;local value=tonumber(patch[dy+1]:sub(dx+1,dx+1))
        if value>0 and x>=0 and x<13 and y>=0 and y<10 then m.layers[y*13+x+1]=value end
      end end end
    end
  end
  local items,rocks={},{}
  for i,o in ipairs(self.mining_objects) do
    if o.item:find('ROCK_') then rocks[#rocks+1]=i
    elseif not o.item:find('ARMOR_FOSSIL') and o.weight>0 then
      for _=1,math.max(1,math.floor(o.weight)) do items[#items+1]=i end
    end
  end
  local function place(id)
    local d=self.mining_objects[id]
    for _=1,150 do
      local x,y=self:random(14-d.width)-1,self:random(11-d.height)-1
      local cells={};local clear=true
      for dy=0,d.height-1 do for dx=0,d.width-1 do
        if not d.mask or d.mask[dy*d.width+dx+1]==1 then
          local k=(y+dy)*13+x+dx+1;cells[#cells+1]=k;if m.occupied[tostring(k)] then clear=false end
        end
      end end
      if clear then local o={id=id,x=x,y=y,cells=cells,rock=d.item:find('ROCK_')~=nil};m.objects[#m.objects+1]=o
        for _,k in ipairs(cells) do m.occupied[tostring(k)]=#m.objects end;return true
      end
    end
    return false
  end
  local n=self:random(3)+1
  for _=1,n do place(items[self:random(#items)]) end
  for _=1,self:random(4)+2 do place(rocks[self:random(#rocks)]) end
  m.total=0;for _,o in ipairs(m.objects) do if not o.rock then m.total=m.total+1 end end
  self.s.records.excavations=self.s.records.excavations+1
  return m
end
function U:reward(o,integrity)
  local d=self.mining_objects[o.id];local color=d.item:match('_(%u+)_SPHERE')
  if color then
    local size=(color=='PRISM' or color=='PALE') and 1 or self:random(4)
    if d.item:find('LARGE') then size=size+10 end
    size=size+math.floor(math.max(0,integrity)/39)
    local ok=self:addSphere(color:lower(),size)
    if not ok then
      -- Recovered finds survive a full pocket in a separate claimable storage queue.
      self.s.overflow=self.s.overflow or {};self.s.overflow[#self.s.overflow+1]={color=color:lower(),size=size}
    end
  else self.s.treasures[d.item]=(self.s.treasures[d.item] or 0)+1 end
  self.s.records.recovered=self.s.records.recovered+1
end
function U:hit(m,x,y)
  if m.complete or x<0 or x>12 or y<0 or y>9 then return end
  local hammer=m.tool=='hammer';m.integrity=math.max(0,m.integrity-(hammer and 8 or 4));m.hits=m.hits+1
  local center=y*13+x+1;m.layers[center]=math.max(0,m.layers[center]-2)
  local oi=m.occupied[tostring(center)];local rock=oi and m.objects[oi].rock and m.layers[center]==0
  if not rock then
    for dy=-1,1 do for dx=-1,1 do
      local nx,ny=x+dx,y+dy
      if nx>=0 and nx<13 and ny>=0 and ny<10 and (dx~=0 or dy~=0) then
        local amount=(dx==0 or dy==0) and (hammer and 2 or 1) or (hammer and 1 or 0)
        local k=ny*13+nx+1;m.layers[k]=math.max(0,m.layers[k]-amount)
      end
    end end
  end
  local found={}
  for _,o in ipairs(m.objects) do if not o.rock and not o.recovered then
    local clear=true;for _,k in ipairs(o.cells) do if m.layers[k]>0 then clear=false;break end end
    if clear then o.recovered=true;m.found=m.found+1;self:reward(o,m.integrity);found[#found+1]=self.mining_objects[o.id].item end
  end end
  if m.found==m.total or m.integrity<=0 then m.complete=true end
  return found,rock
end
function U:makeBase()
  local s=self.s;local x,y=self:front()
  if s.inBase or self:open(x,y) then return false,'Face a solid wall to use the Digger Drill.' end
  if s.drills<1 then return false,'You need a Digger Drill. The goods traders sell them.' end
  s.drills=s.drills-1
  s.base={x=x,y=y,entranceX=s.x,entranceY=s.y,decorations={},boulders={},created=os.time()}
  local slots={}
  for _,bx in ipairs({10,12,16,18,20})do for by=10,20,2 do if not (bx==16 and by==12) then slots[#slots+1]={x=bx,y=by}end end end
  for i=1,16 do s.base.boulders[i]=table.remove(slots,self:random(#slots))end
  return true,'Your Secret Base is ready! Face its entrance and press A.'
end
function U:enterBase()
  local s=self.s;s.base.returnX=s.x;s.base.returnY=s.y;s.inBase=true;s.x=15;s.y=20;s.facing='up'
end
function U:exitBase()
  local s=self.s;s.inBase=false;s.x=s.base.returnX or s.base.entranceX;s.y=s.base.returnY or s.base.entranceY;s.facing='down'
end
function U:placeGood(id,x,y)
  local s=self.s;local g=self.goods[id]
  if not s.inBase or not g or (s.goods[tostring(id)] or 0)<1 then return false,'You do not have that decoration.' end
  if #s.base.decorations>=10 then return false,'A normal-flag base holds 10 decorations.' end
  if x<10 or y<10 or x+g.width>22 or y+g.depth>22 or (x<=15 and x+g.width>15 and y+g.depth>19) then return false,'Keep the entrance clear.' end
  for dy=0,g.depth-1 do for dx=0,g.width-1 do if self:blocked(x+dx,y+dy) then return false,'Another decoration is in the way.' end end end
  s.goods[tostring(id)]=s.goods[tostring(id)]-1;s.base.decorations[#s.base.decorations+1]={id=id,x=x,y=y}
  return true,'Decoration placed.'
end
function U:removeGood(index)
  local p=table.remove(self.s.base.decorations,index);if p then local k=tostring(p.id);self.s.goods[k]=(self.s.goods[k] or 0)+1 end
end
return U
