return function(U,callbacks)
  local C={time=0,radar=0,toastTime=0,cooldown=0,mine=U.s.mining}
  local function pretty(s) return (s:gsub('MINING_TREASURE_',''):gsub('MINING_',''):gsub('_',' '):lower():gsub('%a[%w]*',function(w)return w:sub(1,1):upper()..w:sub(2)end)) end
  function C:sound(kind)if callbacks.sound then callbacks.sound(kind)end end
  function C:say(text,done) self.dialog={text=text,done=done};self.menu=nil end
  function C:notice(text) self.toast=text;self.toastTime=3 end
  function C:choose(title,rows,back)
    if #rows==0 then self:say('Nothing here yet.',back);return end
    self.menu={title=title,rows=rows,index=1,back=back}
  end
  function C:mainMenu()
    self:sound('menu')
    local rows={
      {label='Spheres',action=function()self:sphereMenu()end},
      {label='Treasures',action=function()self:treasureMenu()end},
      {label='Goods / Secret Base',action=function()self:baseMenu()end},
      {label='Explorer records',action=function()local r=U.s.records;self:say('Walls excavated: '..r.excavations..'\nFinds recovered: '..r.recovered..'\nSpheres harvested: '..r.spheres,function()self:mainMenu()end)end},
      {label='Underground region',action=function()self:regionMenu()end},
      {label='Save',action=function()local ok=callbacks.save();self:say(ok and 'Your adventure was saved.' or 'Saving failed. Please try again.',function()self:mainMenu()end)end},
      {label='Controls',action=function()self:say('Move with the D-pad. A examines the tile ahead. SELECT scans for treasure. In mining, A digs and B swaps tools. Mouse clicks also dig. START opens this menu.',function()self:mainMenu()end)end},
      {label='Settings',action=function()self:settingsMenu()end},
      {label='Leave Underground',action=function()self.menu=nil;self.mine=nil;U.s.mining=nil;self.dialog=nil;if U.s.inBase then U:exitBase() end;callbacks.leave()end}
    }
    self:choose('EXPLORER KIT',rows)
  end
  function C:settingsMenu()
    self:choose('SETTINGS',{{label='Zoom out: '..U.s.zoomOut..'x',action=function()
      local rows={}
      for i=1,10 do local zoom=i
        rows[#rows+1]={label=i..'x'..(i==1 and ' (normal view)' or '')..(i==U.s.zoomOut and ' - selected' or ''),action=function()
          U.s.zoomOut=zoom;self.menu=nil;self:notice('Zoom out: '..zoom..'x. Save to keep this setting.')
        end}
      end
      self:choose('ZOOM OUT',rows,function()self:settingsMenu()end);self.menu.index=U.s.zoomOut
    end}},function()self:mainMenu()end)
  end
  function C:sphereMenu()
    local rows={};for i,p in ipairs(U.s.spheres) do local index=i;rows[#rows+1]={label=pretty(p.color)..' Sphere ('..p.size..')',action=function()
      self:choose('SPHERE '..p.size,{{label='Bury here',action=function()local _,msg=U:bury(index);self:say(msg,function()self:sphereMenu()end)end},{label='Keep',action=function()self:sphereMenu()end}},function()self:sphereMenu()end)
    end} end
    if U.s.overflow and #U.s.overflow>0 then rows[#rows+1]={label='Collect stored finds ('..#U.s.overflow..')',action=function()
      while #U.s.spheres<40 and #U.s.overflow>0 do local p=table.remove(U.s.overflow,1);U:addSphere(p.color,p.size) end;self:sphereMenu()
    end} end
    self:choose('SPHERES '..#U.s.spheres..'/40',rows,function()self:mainMenu()end)
  end
  function C:treasureMenu(vendor)
    local rows={}
    for item,n in pairs(U.s.treasures) do if n>0 then local id=item;rows[#rows+1]={label=pretty(item)..' x'..n,action=function()
      if vendor then
        local color=U.colors[(#id%5)+1];local size=5+(#id%16)
        self:choose('TRADE '..pretty(id),{{label='For '..color..' Sphere ('..size..')',action=function()
          local ok,msg=U:addSphere(color,size);if ok then U.s.treasures[id]=U.s.treasures[id]-1;msg='Trade complete!' end
          self:say(msg,function()self:treasureMenu(true)end)
        end},{label='Keep',action=function()self:treasureMenu(true)end}},function()self:treasureMenu(true)end)
      else self:choose(pretty(id),{{label='Send to FireRed Bag',action=function()local ok,msg=callbacks.transfer(id);if ok then U.s.treasures[id]=U.s.treasures[id]-1 end;self:say(msg,function()self:treasureMenu()end)end},{label='Keep Underground',action=function()self:treasureMenu()end}},function()self:treasureMenu()end) end
    end} end end
    table.sort(rows,function(a,b)return a.label<b.label end);self:choose(vendor and 'TREASURE TRADER' or 'TREASURES',rows,function()self:mainMenu()end)
  end
  function C:baseMenu()
    local rows={{label='Use Digger Drill ('..U.s.drills..')',action=function()
      local function drill()local _,msg=U:makeBase();self:say(msg)end
      if U.s.base then self:choose('MOVE YOUR BASE?',{{label='Move (packed goods returned)',action=function()
        local x,y=U:front();if U.s.inBase or U:open(x,y) or U.s.drills<1 then self:say('Face a solid wall with a Digger Drill in your kit.');return end
        for i=#U.s.base.decorations,1,-1 do U:removeGood(i)end;drill()
      end},{label='Cancel',action=function()self:baseMenu()end}}) else drill()end
    end}}
    if U.s.inBase then
      rows[#rows+1]={label='Place a decoration',action=function()self:goodsMenu()end}
      rows[#rows+1]={label='Put decorations away',action=function()
        local rr={};for i,p in ipairs(U.s.base.decorations) do local index=i;rr[#rr+1]={label=U.goods[p.id].name,action=function()U:removeGood(index);self:baseMenu()end}end
        self:choose('PUT AWAY',rr,function()self:baseMenu()end)
      end}
      rows[#rows+1]={label='Exit Secret Base',action=function()U:exitBase();self.menu=nil end}
    else rows[#rows+1]={label='View owned goods',action=function()self:goodsMenu()end} end
    self:choose('SECRET BASE',rows,function()self:mainMenu()end)
  end
  function C:goodsMenu()
    local rows={};for id,n in pairs(U.s.goods) do if n>0 then local gid=tonumber(id);rows[#rows+1]={label=U.goods[gid].name..' x'..n,action=function()
      if not U.s.inBase then self:say('Enter your Secret Base to arrange goods.',function()self:baseMenu()end);return end
      self.menu=nil;self.placement={id=gid,x=U.s.x,y=U.s.y-1}
    end} end end
    table.sort(rows,function(a,b)return a.label<b.label end);self:choose('GOODS',rows,function()self:baseMenu()end)
  end
  function C:regionMenu()
    local rows={};for i,r in ipairs(U.regions) do local index=i;rows[#rows+1]={label='Region '..i..(i==U.s.region and ' (current)' or ''),action=function()
      if U.s.inBase then U:exitBase() end
      U.s.x=r.x;U.s.y=r.y;U.s.region=index;U:seedSpots();self.menu=nil;self:notice('Descended into Underground region '..index..'.')
    end}end
    self:choose('DESCENT REGION',rows,function()self:mainMenu()end)
  end
  function C:sell(vendor)
    local rows={};local inventory=U.s.goods
    for id,count in pairs(inventory)do if count>0 then local key=id;local good=vendor.kind=='goods' and U.goods[tonumber(id)]
      local name=good and good.name or id;local color=good and good.sphere or 'red';if color=='none' or color=='random' then color='red'end
      local size=math.max(1,math.floor((good and good.minSize or 10)/2))
      rows[#rows+1]={label=name..' > '..color..' '..size,action=function()
        local ok,msg=U:addSphere(color,size);if ok then inventory[key]=inventory[key]-1;msg='Trade complete!'end
        self:say(msg,function()self:sell(vendor)end)
      end}
    end end
    table.sort(rows,function(a,b)return a.label<b.label end);self:choose('SELL FOR SPHERES',rows,function()self:shop(vendor)end)
  end
  function C:shop(vendor)
    if vendor.kind=='fossils' then self.menu=nil;self.toast=nil;callbacks.fossilShop();return end
    if vendor.kind=='treasures' then self:treasureMenu(true);return end
    local rows={};local day=math.floor(os.time()/86400)
    if vendor.kind=='goods' then
      for j=1,9 do local id=7+((day+vendor.x*7+vendor.y+j*13)% (#U.goods-6));local good=U.goods[id]
        local price=math.max(1,good.minSize or 10);local color=good.sphere~='none' and good.sphere or 'red'
        rows[#rows+1]={label=good.name..' ('..color..' '..price..')',action=function()
          if U:pay(color,price) then local k=tostring(id);U.s.goods[k]=(U.s.goods[k] or 0)+1;self:say('Thank you! '..good.name..' added to Goods.',function()self:shop(vendor)end)
          else self:say('Bring a '..color..' Sphere of size '..price..' or larger.',function()self:shop(vendor)end)end
        end}
      end
    end
      rows[#rows+1]={label='Digger Drill (red 10)',action=function()if U:pay('red',10) then U.s.drills=U.s.drills+1;self:say('One Digger Drill. Find a suitable wall!',function()self:shop(vendor)end)else self:say('Bring a red Sphere of size 10 or larger.',function()self:shop(vendor)end)end end}
    rows[#rows+1]={label='Sell '..vendor.kind,action=function()self:sell(vendor)end}
    self:choose('GOODS TRADER',rows)
  end
  function C:interact()
    local s=U.s;local x,y=U:front();local key=U:key(x,y)
    if s.inBase then
      if s.y>=20 and s.facing=='down' then U:exitBase();return end
      self:baseMenu();return
    end
    for _,v in ipairs(U.vendors) do if v.x==x and v.y==y then self:shop(v);return end end
    if s.base and s.base.x==x and s.base.y==y then U:enterBase();return end
    local buried=s.buried[U:key(s.x,s.y)] and U:key(s.x,s.y) or s.buried[key] and key
    if buried then local _,msg=U:unbury(buried);self:say(msg);return end
    if s.spots[key] then
      self:choose('THE WALL IS SHINING!',{{label='Dig for treasure',action=function()
        s.spots[key]=nil;s.depleted[key]=s.steps;self.menu=nil;self.mine=U:newMine();s.mining=self.mine;self:notice('There are '..self.mine.total..' items buried here!')
      end},{label='Leave it',action=function()self.menu=nil end}});return
    end
    self:notice('Nothing found. SELECT scans for hidden treasure.')
  end
  function C:tick(dt,input)
    self.time=self.time+dt;self.radar=math.max(0,self.radar-dt);self.toastTime=math.max(0,self.toastTime-dt);self.cooldown=math.max(0,self.cooldown-dt)
    U.s.seconds=U.s.seconds+dt
    local function pressed(k)return input:wasPressed(k)end
    if self.dialog then if pressed('a') or pressed('b') then local done=self.dialog.done;self.dialog=nil;if done then done()end end;return end
    if self.menu then
      local m=self.menu
      if pressed('down') then m.index=m.index%#m.rows+1 elseif pressed('up') then m.index=(m.index-2)%#m.rows+1 end
      if pressed('b') then self.menu=nil;if m.back then m.back()end elseif pressed('a') then m.rows[m.index].action()end;return
    end
    if self.mine then
      local m=self.mine
      if m.complete then if pressed('a') or pressed('b') then self.mine=nil;U.s.mining=nil;U:seedSpots()end;return end
      if pressed('start') then self:choose('STOP DIGGING?',{{label='Keep digging',action=function()self.menu=nil end},{label='Finish (keep recovered finds)',action=function()self.menu=nil;self.mine=nil;U.s.mining=nil;U:seedSpots()end},{label='Leave Underground',action=function()self.menu=nil;self.mine=nil;U.s.mining=nil;callbacks.leave()end}});return end
      if pressed('b') or pressed('select') then m.tool=m.tool=='pick' and 'hammer' or 'pick' end
      for dir,d in pairs(U.dirs) do if pressed(dir) then m.x=math.max(0,math.min(12,m.x+d[1]));m.y=math.max(0,math.min(9,m.y+d[2]))end end
      if pressed('a') then self:dig(m.x,m.y)end;return
    end
    if self.placement then
      local p=self.placement;for dir,d in pairs(U.dirs) do if pressed(dir) then p.x=math.max(10,math.min(21,p.x+d[1]));p.y=math.max(10,math.min(21,p.y+d[2]))end end
      if pressed('b') then self.placement=nil elseif pressed('a') then local ok,msg=U:placeGood(p.id,p.x,p.y);self:notice(msg);if ok then self.placement=nil end end;return
    end
    if pressed('start') then self:mainMenu();return end
    if pressed('select') then self.radar=4;self:sound('radar');U:seedSpots() end
    if self.move then self.move.t=self.move.t+dt;if self.move.t>=self.move.duration then self.move=nil end;return end
    if pressed('a') then self:interact();return end
    if self.cooldown>0 then return end
    for _,dir in ipairs({'up','down','left','right'}) do if input:isDown(dir) then
      local s=U.s;local d=U.dirs[dir];s.facing=dir;local nx,ny=s.x+d[1],s.y+d[2]
      if s.inBase and s.y>=21 and (s.x==15 or s.x==16) and dir=='down' then U:exitBase();return end
      if not U:blocked(nx,ny) then
        self.move={x=s.x,y=s.y,t=0,duration=input:isDown('b') and .10 or .16};s.x=nx;s.y=ny;s.steps=s.steps+1
        if s.steps%12==0 then U:seedSpots()end
      else self.cooldown=.10 end
      break
    end end
  end
  function C:dig(x,y)
    local found,rock=U:hit(self.mine,x,y)
    self.swing={x=x,y=y,start=self.time,tool=self.mine.tool,rock=rock}
    self:sound(rock and 'rock' or self.mine.tool)
    if found and #found>0 then self:sound('found');self:notice(pretty(found[1])..' was dug up!')elseif rock then self:notice('Clang! A hard rock blocks the tool.')end
  end
  function C:click(x,y)
    if self.dialog then local done=self.dialog.done;self.dialog=nil;if done then done()end;return end
    if self.menu then return end
    if self.mine then
      if self.mine.complete then self.mine=nil;U.s.mining=nil;U:seedSpots();return end
      if y>=224 and x<208 then self.mine.x=math.floor(x/16);self.mine.y=math.floor((y-224)/16);self:dig(self.mine.x,self.mine.y)
      elseif x>=208 and y>=224 then self.mine.tool=self.mine.tool=='pick' and 'hammer' or 'pick' end
    else self.radar=4;U:seedSpots()end
  end
  return C
end
