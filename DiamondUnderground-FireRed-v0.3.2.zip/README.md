# Diamond Underground — FireRed (single-player beta 0.3.2)

## Changes in 0.3.2

- START -> Settings -> Zoom out offers 1x (normal) through 10x.
- The view changes immediately; use Save to retain your preference across sessions.
- World geometry and characters zoom together. Menus, mining and the minimap
  retain their normal sizes. Select 1x to restore the original view.

## Changes in 0.3.1

- Single 240x160 game view, using the same window scaling as normal FireRed.
- Small translucent map in the top-right corner, with player position and radar.
- Menus, dialogs, Secret Base placement and fossil shops fit the single screen.
- Mining artwork fits the screen with matching mouse hit detection. The minimap
  is hidden during mining and the fossil shop so it does not cover their controls.

## Changes in 0.3.0

- Former trap traders use the native FireRed Hiker overworld sprite.
- Their fossil exchange uses the actual FireRed shop UI: choose Helix Fossil,
  Dome Fossil or Old Amber, select a quantity, and confirm the exchange.
- Each fossil costs one sphere of any color or size. Smallest spheres are spent
  first. Fossils go directly to the FireRed Bag; Pokedollars are untouched.
- All trap gameplay is removed. Old inventory and world traps are cleared when
  loading Underground state. Digger Drills are now sold by goods traders.

## Fixes retained from 0.2.1

- Preserve Underground state when the engine rebuilds save metadata. This fixes
  lost departure coordinates after quick-save, and also preserves inventories,
  records, sphere burial, mining progress and the one-time purchase flag.
- Use the engine's supported walking phase, with alternating stride frames and
  the native stand/stride/stand cadence for both FireRed player sprites.
- Remove the hardcoded rival-house exit. Recover an older in-progress trip's
  departure from its surface save snapshot when available.

A playable Underground recreation for the FireRed engine bundled in the supplied
`gen1recomp-win64` installation. Its scenery and sprites are extracted from your
local **Pokémon Diamond USA, Revision 5** ROM. This is a standalone replacement
for the earlier Dungeon Delvers adaptation; it does not require that mod.

## Install and enter

1. Import `DiamondUnderground-FireRed-v0.3.2.zip` with the launcher's mod ZIP importer,
   replacing the earlier version of this mod if installed.
2. Enable **Diamond Underground - FireRed** for FireRed. Disable **Dungeon Delvers
   - FireRed: Oak's Descent** and any other mod that redirects Oak's lab. Restart
   when prompted. The manifest also declares the old dungeon mod incompatible.
3. Buy **Diamond Digging** at a PokéMart for **500**. Only one can be purchased;
   it disappears from shop stock immediately and stays unavailable after saving.
4. Open **Bag → Key Items → Diamond Digging → Use**. Answer **Yes** to
   “Are you ready to enter the Underground?” The game quick-saves before entry.
   **No** cancels. A failed save prevents travel and displays an error.
5. Press **START → Leave Underground** to return to the exact map, tile and facing
   where you used the item. The same exit is available while mining. Oak's lab
   entrance now behaves normally. The player keeps their existing FireRed sprite.

To remove the mod, leave the Underground, save, then disable it.
Do not disable it while your saved location is the custom Underground
map. Your normal Pokémon, money and items are retained.

## What is playable

- The original 480×480 Diamond Underground map, with all six disconnected regions,
  original collision data, textured 3D tunnels, and the original radar artwork as a translucent minimap.
- Your existing FireRed player sprite, including its active palette; FireRed Hiker fossil traders.
- Sparkling walls, radar scans, and the 13×10 mining board. Pickaxe and hammer use
  different excavation patterns and wall-stability costs. Original treasure,
  rock, dirt, tool and effect artwork is used. Already uncovered finds survive
  a collapse. A saved unfinished wall resumes without duplicating rewards.
- Spheres, including burial, same-color merging, real-day growth and harvesting.
  The sphere pocket holds 40; excess recovered spheres wait in stored finds.
- Treasure traders, daily rotating goods stocks, buying and selling for
  spheres, and a Digger Drill. Compatible treasures can be sent to the FireRed
  Bag; Diamond-only items stay in Underground storage or can be traded.
- Secret Bases: drill a wall, enter it, use the PC/menu, preview and place owned
  furnishings, and put them away. All 138 original furnishing model entries are
  imported. A normal-flag base has 16 boulders and holds 10 decorations, consistent
  with playing without multiplayer flag upgrades.
- Persistent discoveries, inventories, buried spheres, base furnishings,
  position, records and mining progress in the existing FireRed save format.

## Controls

The mod follows your configured game buttons. With the supplied engine defaults:

| Action | Keyboard / input |
| --- | --- |
| Move | Arrow keys or WASD |
| Examine / confirm / dig | Z, Enter or Space (A) |
| Cancel / change mining tool | X or Backspace (B) |
| Run | Hold B while walking |
| Radar scan | Tab or Shift (SELECT); clicking the screen also scans |
| Explorer Kit / exit | Escape or keypad Enter (START) |
| Mine with the mouse | Click a wall cell; click the tool panel to switch tools |
| Save | Explorer Kit → Save; the engine's F1 save shortcut also works |

Face a sparkling wall and press A to start mining. For a buried sphere, stand
on its tile or face it and press A. Face a FireRed Hiker and press A to trade.
Face a solid wall and use Goods / Secret Base → Digger Drill to make your base.
Face the resulting entrance and press A to enter. The base menu is also available
from START. Leave the base through the center doorway or its menu.

## Scope and differences from the DS game

This is a **playable beta recreation, not a verified identical port of Diamond's
entire Underground engine**. The visuals use the original ROM data, while the
runtime, menus and gameplay logic have been reimplemented for LÖVE/FireRed.

- Local single-player only: no wireless players, visiting friends, flag stealing,
  multiplayer flag-rank upgrades, or online services.
- Because the Digging item is the surface entrance, the Explorer Kit offers a region
  selector to reach the six otherwise disconnected sections.
- Keyboard/mouse controls replace touchscreen and microphone requirements.
- Music and sound feedback currently use FireRed audio, not Diamond's soundtrack.
- Camera projection, timing, vendor prices/stock selection, growth rates are adaptations; they have not been certified frame-for-frame
  against Diamond. Original Underground Man overworld quests are not recreated.
- Diamond-exclusive fossils/items are collectibles/trade goods here. They do not
  add missing Pokémon or item effects to FireRed.

## Verification

Checked with the actual LuaJIT/LÖVE libraries and engine source from your executable:

- 250 mining layouts, non-overlapping shapes, excavation costs, rewards, sphere
  merging/payment, base collision and placement, and the exit menu.
- The actual save serializer with an unfinished mining board.
- Loading through the engine's mod sandbox and native FireRed cave data.
- An isolated fresh FireRed session: normal Oak lab entry, native shop purchase,
  insufficient funds, quantity limit, permanent stock removal, native Bag Use,
  confirmation cancellation, save failure, save-before-warp, save-codec roundtrip,
  original FireRed sprite, correct area name, and return to the departure tile/facing.
- Native fossil shop purchases, quantities, cancellation, insufficient spheres,
  full Bag, all three fossils, unchanged money, and legacy trap removal.
- Real rendered screenshots of tunnels, mining, Secret Base and the START menu.

These automated checks are not a long manual playthrough or compatibility testing
with every other installed mod. No original ROM, executable or existing save was
modified to build or test this package.

## Asset provenance

The graphics were converted locally from the ROM path you supplied. The ROM itself
is not included. See `assets/source.json` for the imported area/map identifiers.
Nintendo, Game Freak and The Pokémon Company retain ownership of their game art.

Reference projects used to understand formats and behavior:

- [pret/pokediamond](https://github.com/pret/pokediamond)
- [pret/pokeplatinum](https://github.com/pret/pokeplatinum), Underground subsystem
- [apicula](https://github.com/scurest/apicula), Nitro model/texture conversion

The extraction/conversion scripts and verification harnesses are retained alongside
the mod in the local workspace's `tools` and `tests` directories.

If an older save has already lost its departure coordinates, the mod tries the
available surface save snapshot. If neither has a valid return point, it explains
that the surface quick-save must be loaded and used for a fresh entry. It no longer
sends the player to an unrelated fixed location. Previously erased coordinates
or inventory cannot be reconstructed from an Underground-only save.
