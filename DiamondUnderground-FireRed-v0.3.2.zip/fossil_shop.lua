-- Reuse FireRed's actual shop, with an isolated sphere balance instead of money.
return function(U)
  local E={}
  local Shop=require('src.ui.game3.shop_menu')
  local Items=require('src.core.game3.items_data')
  local Bag=require('src.core.game3.bag')
  local Text=require('src.core.game3.rom_text')
  local stock={'HELIX_FOSSIL','DOME_FOSSIL','OLD_AMBER'}
  local fossils={};for _,id in ipairs(stock)do fossils[id]=true;local n=Items.toNumericId(id);if n then fossils[n]=true end end
  function E:isOpen()return self.active and Shop.isOpen() and Shop._session==self.proxy end
  local info=Items.info
  Items.info=function(id)
    local original=info(id)
    if E.active and fossils[id] and original then
      local copy={};for k,v in pairs(original)do copy[k]=v end;copy.price=1;return copy
    end
    return original
  end
  local description=Items.description
  Items.description=function(id)
    if E:isOpen() and fossils[id]then return 'Trade 1 sphere for this fossil.\nSmallest spheres go first.'end
    return description(id)
  end
  local plain,box=Text.plain,Text.box
  Text.plain=function(id,opts)
    if E:isOpen()then
      if id=='gText_TrainerCardMoney' then return 'SPHERES' end
      if id=='gText_PokedollarVar1' then return tostring(opts.stringVars[1])end
    end
    return plain(id,opts)
  end
  Text.box=function(id,opts)
    if E:isOpen()then
      if id=='gText_YouDontHaveMoney' then return 'You need more spheres.'end
      if id=='gText_Var1AndYouWantedVar2' then return 'Trade '..Shop.qty..' sphere(s)\nfor '..Shop.qty..' fossil(s)?'end
    end
    return box(id,opts)
  end
  function E:open(game)
    local s=game.session;U:state(s);s.bag=s.bag or Bag.new()
    self.session=s
    -- Only the bag is shared; shop writes to money cannot reach real money.
    self.proxy=setmetatable({money=#U.s.spheres,bag=s.bag,meta=s.meta},{__index=s})
    self.active=true
    Shop.show({session=self.proxy,items=stock,diamondFossilExchange=true,onClose=function()self.active=false;self.proxy=nil end})
    Shop.mode='buy';Shop._status=nil
  end
  function E:close()if self:isOpen()then Shop.close()end;self.active=false end
  function E:tick(input)
    if not self:isOpen()then return end
    if Shop.mode=='buy' and (input:wasPressed('b') or input:wasPressed('start') or
      (input:wasPressed('a') and Shop.cursor==#stock+1)) then self:close();return end
    self.proxy.money=#U.s.spheres;self.proxy.bag=self.session.bag
    local before=self.proxy.money
    Shop.handleInput(input)
    local spent=before-self.proxy.money
    -- Native shop charges only after Bag.canAdd and Bag.add both succeed.
    for _=1,spent do
      local smallest=1
      for i,p in ipairs(U.s.spheres)do if p.size<U.s.spheres[smallest].size then smallest=i end end
      table.remove(U.s.spheres,smallest)
    end
  end
  function E:draw(background)
    local g=love.graphics
    self.canvas=self.canvas or g.newCanvas(240,160);self.canvas:setFilter('nearest','nearest')
    -- Render at native coordinates so the shop's pixel scissor clips correctly.
    g.push('all');g.setCanvas(self.canvas);g.origin();g.clear();g.setColor(1,1,1)
    g.draw(background,0,0);Shop.draw();g.pop()
    g.setColor(1,1,1);g.draw(self.canvas,0,0)
  end
  return E
end
