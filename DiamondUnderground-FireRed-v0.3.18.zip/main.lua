return function(mod)
  local function module(name)return assert(loadstring(assert(mod:read(name..'.lua')),'@diamond_underground/'..name..'.lua'))()end
  local U=module('core').new(mod)
  local Map=require('src.core.game3.map')
  local Runtime=require('src.core.game3.runtime')
  local Layout=require('src.core.game3.layout_native')
  local Warp=require('src.core.game3.warp')
  local Game=require('src.core.Game3')
  local Bag=require('src.core.game3.bag')
  local Audio=require('src.core.game3.audio')
  -- Game3.saveGame rebuilds meta before writing. Preserve only this mod's keys
  -- through that rebuild; keeping them solely in Schema.toSaveTable is too late.
  local SaveData=require('src.core.SaveData')
  local buildMeta=SaveData.buildMeta
  SaveData.buildMeta=function(mods,previous,started)
    local meta=buildMeta(mods,previous,started)
    if type(previous)=='table' then
      meta.diamondUnderground=previous.diamondUnderground
      meta.diamondDiggingPurchased=previous.diamondDiggingPurchased
    end
    return meta
  end
  local gameRef,C,R,E,Battle
  local function clearBattleFade()
    local ok,Fade=pcall(require,'src.ui.game3.fade')
    if ok and Fade and Fade.clear then Fade.clear()end
  end
  local Cynthia={id=9999,name='Cynthia',class=90,className='CHAMPION',pic=9999,partySize=6,lastLevel=77,aiFlags=7,items={0,0,0,0},dialogs={}}
  local function installCynthiaBattleArt()
    local Trainers=require('src.core.game3.scripting.trainers')
    local trainerGet=Trainers.get
    Trainers.get=function(id)if tonumber(id)==Cynthia.id then return Cynthia end;return trainerGet(id)end
    local Pics=require('src.core.game3.trainer_pic')
    local front=Pics.front
    Pics.front=function(id)
      if tonumber(id)~=Cynthia.pic then return front(id)end
      if not Cynthia.art then
        local image=mod.assets:image('assets/npc/cynthia_battle.png');image:setFilter('nearest','nearest')
        Cynthia.art={image=image,w=64,h=64}
      end
      return Cynthia.art
    end
  end
  local function cynthiaBattle(game)
    Battle=Battle or require('src.core.game3.battle')
    if Battle.isActive()then return end
    local party={{species=142,level=65},{species=141,level=67},{species=149,level=72},{species=145,level=71},{species=9,level=77},{species=151,level=75}}
    local ok,err=Battle.start({session=game.session,playerParty=game.session.party,foe={party=party},trainerId=Cynthia.id,trainerName=Cynthia.name,trainerPicId=Cynthia.pic,trainerClass=90,aiFlags=7,defeatText='Cynthia: That was an excellent battle. Your Pokémon have great potential!',terrain='CAVE',onDone=function(result)
      clearBattleFade()
      if result=='win' then U.s.cynthiaDefeated=true;C:say('Cynthia: You have shown remarkable strength. I am glad we could battle!')
      else
        require('src.core.game3.party').healAll(game.session.party)
        C:say('Cynthia: All healed up. Come see me when you are ready to fight again.')
      end
    end})
    if not ok then C:say('Cynthia cannot battle right now: '..tostring(err))end
  end
  installCynthiaBattleArt()
  local function build(game)
    if game.data.maps[U.MAP] then return end
    local source=assert(game.data.maps.FR_MT_MOON_1F or game.data.maps.FR_MT_MOON_B1F,'FireRed cave data is missing. Reimport FireRed.')
    Map.ensureMidLayout(game,source.id or 'FR_MT_MOON_1F',source)
    local floor
    for _,c in ipairs(source.midLayout.cells) do if c.elev==3 and c.coll==0 then floor=c.mid;break end end
    assert(floor,'No FireRed floor metatile found')
    local cells={};for i=1,64 do cells[i]={mid=floor,coll=0,elev=3}end
    local pair=source.midLayout.pair or source.pair
    game.data.maps[U.MAP]={id=U.MAP,name='The Underground',width=8,height=8,pair=pair,tileset=source.tileset,native=true,
      environment='CAVE',kind='cave',mapType=4,cave=0,music=source.music,
      showMapName=0,weather=0,bikingAllowed=0,allowRunning=1,allowEscaping=0,connections={},warps={},objects={},coordEvents={},bgEvents={},mapScripts={},
      midLayout=Layout.fromDecoded({width=8,height=8,cells=cells,borderWidth=1,borderHeight=1,borderMids={floor}},U.MAP,pair)}
  end
  local function active(game)return game and game.phase=='field' and game.session and game.session.map==U.MAP and not Warp.isBusy()end
  local function controller(game)
    U:state(game.session)
    if not C or C.session~=game.session then
      C=module('controller')(U,{
        sound=function(kind)
          local ids={pick=31,hammer=20,rock=7,found=25,radar=65,menu=6}
          if kind=='alert' and Audio.playCry then pcall(Audio.playCry,25,0,0)
          elseif ids[kind] and Audio.playSe then pcall(Audio.playSe,ids[kind])end
        end,
        save=function()return game:saveGame()end,
        leave=function()
          -- Do not carry a battle transition's dark frame back to the surface.
          clearBattleFade()
          local dest=U:returnLocation(game)
          if not dest then C:say('This older save has no recorded entry location. Load your surface quick-save and enter again using Diamond Digging.');return end
          local ok,err=Warp.request(nil,game,dest.map,dest.x,dest.y,dest.facing,{fade=false})
          if not ok then C:say('Could not leave: '..tostring(err))end
        end,
        fossilShop=function()E:open(game)end,
        cynthiaBattle=function()cynthiaBattle(game)end,
        transfer=function(id)
          local key=id:gsub('^MINING_TREASURE_',''):gsub('^MINING_','')
          local allowed={HELIX_FOSSIL=true,DOME_FOSSIL=true,OLD_AMBER=true,EVERSTONE=true,THUNDER_STONE=true,FIRE_STONE=true,WATER_STONE=true,LEAF_STONE=true,MOON_STONE=true,SUN_STONE=true,STAR_PIECE=true,HEART_SCALE=true,REVIVE=true,MAX_REVIVE=true,HARD_STONE=true,LIGHT_CLAY=false}
          if not allowed[key] then return false,'This Diamond item has no FireRed equivalent. Keep it in Treasures or trade it Underground.' end
          game.session.bag=game.session.bag or Bag.new()
          if Bag.add(game.session.bag,key,1) then return true,'The item was sent to your FireRed Bag.'end
          return false,'Your FireRed Bag is full.'
        end
      });C.session=game.session;C.game=game;C.exchange=E
      U:seedSpots()
      if not U.s.intro then U.s.intro=true;C:say('Welcome to the Underground! Your Explorer Kit has mining tools and a Digger Drill. Look for shining walls, or press SELECT to scan. START opens your kit and the exit.')end
    end
    return C
  end
  local originalLoad=Map.load
  Map.load=function(owner,game,id,opts)
    gameRef=game or gameRef
    if id==U.MAP then
      build(game);U:state(game.session or Runtime.getSession())
      local copy={};for k,v in pairs(opts or {})do copy[k]=v end
      copy.x,copy.y,copy.facing=4,4,'down'
      return originalLoad(owner,game,U.MAP,copy)
    end
    return originalLoad(owner,game,id,opts)
  end
  module('travel')(U,build)
  E=module('fossil_shop')(U)
  local originalUpdate=Game.fixedUpdate
  Game.fixedUpdate=function(game,dt)
    if Battle and Battle.isActive()then
      game.input:step()
      -- Battle needs Runtime's UI, transition, fade and field-lock updates.
      -- Calling Battle.update alone leaves the intro sequence half-initialized.
      return Runtime.update(dt or 1/60)
    end
    if active(game) then
      local c=controller(game);game.input:step()
      if game.input.softResetStep and game.input:softResetStep() then E:close();game.input:reset();game:returnToTitle();C=nil;return end
      if E:isOpen() then E:tick(game.input)else c:tick(dt or 1/60,game.input)end
      if Runtime.pumpRtc then Runtime.pumpRtc(game,dt or 1/60)end
      if Audio.pumpBgm then Audio.pumpBgm()end
      return
    end
    return originalUpdate(game,dt)
  end
  local originalDraw=Game.draw
  Game.draw=function(game)
    if Battle and Battle.isActive()then
      local Display=require('src.core.game3.display')
      return Display.present(game,love.graphics.getDimensions())
    end
    if active(game) then
      local c=controller(game);R=R or module('render')(mod,U)
      R:draw(c,love.graphics.getDimensions());return
    end
    return originalDraw(game)
  end
  local originalMouse=Game.mousepressed
  Game.mousepressed=function(game,x,y,button,istouch)
    if active(game) and R and R.scale and button==1 then
      if E:isOpen()then return end
      local c=controller(game);local px,py=R:inputPoint(x,y,c)
      if px then c:click(px,py)end
      return
    end
    return originalMouse(game,x,y,button,istouch)
  end
end
