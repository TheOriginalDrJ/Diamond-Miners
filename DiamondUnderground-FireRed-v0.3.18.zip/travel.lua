return function(U,build)
  local T={ID='DIAMOND_DIGGING'}
  local Items=require('src.core.game3.items_data')
  local Bag=require('src.core.game3.bag')
  local Shop=require('src.ui.game3.shop_menu')
  local BagChrome=require('src.ui.game3.bag_chrome')
  local iconImage=BagChrome.iconImage
  local kitIcon
  BagChrome.iconImage=function(id)
    if id~=T.ID then return iconImage(id)end
    if not kitIcon then
      kitIcon=assert(U.mod.assets:image('assets/ui/miner_kit.png'))
      kitIcon:setFilter('linear','linear')
    end
    return kitIcon
  end
  local drawItemIcon=BagChrome.drawItemIcon
  BagChrome.drawItemIcon=function(id,x,y,scale)
    if id~=T.ID then return drawItemIcon(id,x,y,scale)end
    local im=BagChrome.iconImage(id);local w,h=im:getDimensions()
    local size=24*(scale or 1);local fit=size/math.max(w,h)
    love.graphics.setColor(1,1,1,1)
    love.graphics.draw(im,(x or 0)+(size-w*fit)/2,(y or 0)+(size-h*fit)/2,0,fit,fit)
    return true
  end
  local Runtime=require('src.core.game3.runtime')
  local ItemUse=require('src.core.game3.item_use')
  local Message=require('src.ui.game3.message')
  local Choice=require('src.ui.game3.choice')
  local Field=require('src.core.game3.field')
  local Warp=require('src.core.game3.warp')
  local Player=require('src.core.game3.player')
  local Ow=require('src.core.game3.ow_sprites')
  local Sections=require('src.import.gba.map_sections_extract')
  local info=Items.info
  Items.info=function(id)
    if id==T.ID then return {id=T.ID,name='Diamond Digging',pocket='KEY_ITEMS',fieldUse='diamond_digging',price=500,
      description='An explorer kit for entering\nthe Underground.',importance=1,registrability=0,battleUsage=0}end
    return info(id)
  end
  local sectionInfo=Sections.getInfo
  Sections.getInfo=function(sec,id,floor)
    if id==U.MAP then return {id='MAPSEC_DIAMOND_UNDERGROUND',name='The Underground',rawName='The Underground',floorNum=0,resolved=true}end
    return sectionInfo(sec,id,floor)
  end
  local function owned(s)return s and ((s.meta and s.meta.diamondDiggingPurchased) or (s.bag and Bag.has(s.bag,T.ID,1)))end
  local canAdd=Bag.canAdd
  Bag.canAdd=function(bag,id,n)
    if id==T.ID and ((tonumber(n) or 1)~=1 or Bag.has(bag,id,1)) then return false end
    return canAdd(bag,id,n)
  end
  local show=Shop.show
  Shop.show=function(opts)
    if opts and opts.diamondFossilExchange then return show(opts)end
    opts=opts or {};local copy={};for k,v in pairs(opts)do copy[k]=v end
    local s=opts.session or Runtime.getSession();copy.items={}
    for _,id in ipairs(opts.items or {})do if id~=T.ID then copy.items[#copy.items+1]=id end end
    if s and not owned(s) then copy.items[#copy.items+1]=T.ID end
    return show(copy)
  end
  local handle=Shop.handleInput
  Shop.handleInput=function(input)
    local special=Shop._pending and Shop._pending.id==T.ID
    if special then Shop.qty=1 end
    local filtered=input
    if special and Shop.mode=='buy_qty' then
      filtered=setmetatable({wasPressed=function(_,key)
        if key=='up' or key=='down' or key=='left' or key=='right' then return false end
        return input:wasPressed(key)
      end},{__index=input})
    end
    local result=handle(filtered)
    local s=Shop._session
    if s and s.bag and Bag.has(s.bag,T.ID,1) then
      s.meta=s.meta or {};s.meta.diamondDiggingPurchased=true
      local changed=false;local rows={}
      for _,id in ipairs(Shop._items or {})do if id==T.ID then changed=true else rows[#rows+1]=id end end
      if changed then Shop._items=rows;Shop._rowsGen=(Shop._rowsGen or 0)+1;Shop.cursor=math.min(Shop.cursor or 1,#rows+1)end
    end
    return result
  end
  function T.prompt(game)
    local s=game and game.session
    if not s or s.map==U.MAP or Warp.isBusy()then return end
    Field.lock()
    Message.showStay('Are you ready to enter the Underground?',{speed=0})
    Choice.yesNo(function(yes)
      Message.close()
      if not yes then Field.unlock();return end
      local state=U:state(s)
      local old=state.returnLocation
      state.returnLocation={map=s.map,x=Player.cellX or s.x,y=Player.cellY or s.y,facing=Player.facing or s.facing or 'down'}
      state.playerGraphicsId=Ow.playerGraphicsId(game)
      local ok,saved=pcall(game.saveGame,game)
      if not ok or saved~=true then
        state.returnLocation=old
        Message.show('The game could not be saved. You have not entered the Underground.',function()Field.unlock()end)
        return
      end
      build(game)
      Field.unlock()
      local warped,err=Warp.request(nil,game,U.MAP,4,4,'down',{fade=false})
      if not warped then Message.show('Could not enter the Underground: '..tostring(err))end
    end,{left=20,top=6})
  end
  local use=ItemUse.useField
  ItemUse.useField=function(session,bag,id,...)
    if id~=T.ID then return use(session,bag,id,...)end
    local game=Runtime._game
    if not game or not Bag.has(bag,T.ID,1)then return false,'none','You do not have Diamond Digging.'end
    if session.map==U.MAP or Warp.isBusy()then return false,'none','Diamond Digging cannot be used right now.'end
    local cb=function()T.prompt(game)end
    if ItemUse.setUpOnFieldCallback(cb) then return true,'escape' end
    cb();return true,'diamond_digging'
  end
  return T
end

