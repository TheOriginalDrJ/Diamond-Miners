return function(mod,U)
  local R={images={},models={},quads={}};local g=love.graphics
  function R:image(path)
    if not self.images[path] then local im=assert(mod.assets:image('assets/'..path));im:setFilter('nearest','nearest');self.images[path]=im end
    return self.images[path]
  end
  function R:init()
    if self.canvas then return end
    self.canvas=g.newCanvas(240,160);self.canvas:setFilter('nearest','nearest')
    self.world=g.newCanvas(240,160);self.world:setFilter('nearest','nearest')
    self.depth=g.newCanvas(240,160,{format='depth24',readable=false})
    self.font=g.newFont(9);self.small=g.newFont(8)
    self.effects=assert(loadstring(assert(mod:read('assets/effects.lua'))))()
    self.shader=g.newShader([[
      varying vec4 tint;
      #ifdef VERTEX
      uniform vec3 camera;
      uniform vec3 offset;
      uniform float zoomOut;
      vec4 position(mat4 transform_projection, vec4 vertex_position) {
        vec3 p=vertex_position.xyz+offset-camera;
        vec2 screen=vec2(120.0+p.x/zoomOut, 90.0+(p.z*0.70-p.y*0.82)/zoomOut);
        vec4 result=transform_projection*vec4(screen,0.0,1.0);
        result.z=-(p.z*0.82+p.y*0.70)/(2048.0*zoomOut);
        return result;
      }
      #endif
      #ifdef PIXEL
      vec4 effect(vec4 color, Image texture, vec2 uv, vec2 pixel) {
        vec4 c=Texel(texture,uv)*color;
        if(c.a<0.1) discard;
        return c;
      }
      #endif
    ]])
  end
  local format={{'VertexPosition','float',3},{'VertexTexCoord','float',2},{'VertexColor','float',4}}
  function R:effect(name,frame,x,y)
    local frames=self.effects[name];if not frames then return end
    g.setColor(1,1,1);g.draw(self:image('effects/'..frames[(frame-1)%#frames+1]),x-64,y-64)
  end
  function R:model(name,x,y,z)
    if not self.models[name] then
      local data=assert(loadstring(assert(mod:read('assets/models/'..name..'.lua'))))();local parts={}
      for _,p in ipairs(data) do
        local mesh=g.newMesh(format,p.vertices,'triangles','static')
        if p.texture~='' then local im=self:image('models/'..p.texture);im:setWrap('repeat','repeat');mesh:setTexture(im) end
        parts[#parts+1]=mesh
      end
      self.models[name]=parts
    end
    self.shader:send('offset',{x,y,z})
    for _,mesh in ipairs(self.models[name]) do g.draw(mesh) end
  end
  function R:sprite(path,x,z,columns,index)
    local im=self:image(path);local w,h=im:getDimensions();columns=columns or 1;index=index or 1
    w=w/columns
    local u0=(index-1)/columns;local u1=index/columns
    -- Upright billboard in the original world coordinates; feet rest on the floor.
    local hh=h/0.82
    local mesh=g.newMesh(format,{{-w/2,hh,0,u0,0,1,1,1,1},{w/2,hh,0,u1,0,1,1,1,1},{w/2,0,0,u1,1,1,1,1},{-w/2,0,0,u0,1,1,1,1}},'fan','stream')
    mesh:setTexture(im);self.shader:send('offset',{x,0,z});g.draw(mesh);mesh:release()
  end
  function R:fieldSprite(path,x,y,w,h,index)
    -- Field NPCs are drawn after the 3D mine canvas.  This deliberately keeps
    -- the mine's depth buffer and dark model shading from affecting their
    -- lower pixels.
    local im=self:image(path);local iw,ih=im:getDimensions();local columns=4
    local quad=g.newQuad((index-1)*iw/columns,0,iw/columns,ih,iw,ih)
    -- love.graphics.draw takes scale factors here, not output pixel dimensions.
    -- Convert our desired FireRed-sized dimensions into scale factors.
    g.setColor(1,1,1,1);g.draw(im,quad,x-w/2,y-h,0,w/(iw/columns),h/ih)
  end
  function R:playerPose(C,spr)
    local Ow=require('src.core.game3.ow_sprites')
    local progress=C.move and C.move.t/C.move.duration or 0
    -- Match the native stand / stride / stand cadence and alternate legs on
    -- consecutive tile steps. Ow.pose accepts true or 1, not fractional phases.
    local walking=C.move~=nil and progress>=.25 and progress<.75
    return Ow.pose(spr,U.s.facing,walking,(U.s.steps or 0)%2==0)
  end
  function R:player(C)
    local Ow=require('src.core.game3.ow_sprites')
    local id=U.s.playerGraphicsId or Ow.playerGraphicsId(C.game)
    local spr=assert(Ow.getDraw(id),'FireRed player sprite is unavailable')
    local frame,flip=self:playerPose(C,spr)
    self:actor(spr,frame,flip,self.cx,self.cy)
  end
  function R:actor(spr,frame,flip,x,z)
    local q=spr.quads[frame];local qx,qy,qw,qh=q:getViewport();local iw,ih=spr.image:getDimensions()
    local u0,u1=qx/iw,(qx+qw)/iw;if flip then u0,u1=u1,u0 end
    local v0,v1=qy/ih,(qy+qh)/ih;local w,h=spr.width,spr.height/.82
    local mesh=g.newMesh(format,{{-w/2,h,0,u0,v0,1,1,1,1},{w/2,h,0,u1,v0,1,1,1,1},{w/2,0,0,u1,v1,1,1,1,1},{-w/2,0,0,u0,v1,1,1,1,1}},'fan','stream')
    mesh:setTexture(spr.image);self.shader:send('offset',{x,0,z});g.draw(mesh);mesh:release()
  end
  function R:project(x,y,height)
    local zoom=U.s.zoomOut or 1
    return 120+(x*16+8-self.cx)/zoom,90+((y*16+8-self.cy)*.7-(height or 0)*.82)/zoom
  end
  function R:worldDraw(C)
    local s=U.s;g.setCanvas({self.world,depthstencil=self.depth});g.clear(.06,.035,.025,1,0,1);g.origin()
    g.setColor(1,1,1);g.setDepthMode('less',true);g.setMeshCullMode('none');g.setShader(self.shader)
    local zoom=s.zoomOut or 1;self.shader:send('zoomOut',zoom)
    local px,py=s.x,s.y
    if C.move then local t=math.min(1,C.move.t/C.move.duration);px=C.move.x+(s.x-C.move.x)*t;py=C.move.y+(s.y-C.move.y)*t end
    self.cx,self.cy=px*16+8,py*16+8;self.shader:send('camera',{self.cx,0,self.cy})
    if s.inBase then
      self:model('ugmap00c',256,0,256)
      self:model(U.goods[1].mesh,15*16+16,0,12*16+8)
      for _,p in ipairs(s.base.boulders or {})do self:model(U.goods[6].mesh,p.x*16+16,0,p.y*16+16)end
      for _,p in ipairs(s.base.decorations) do local good=U.goods[p.id];self:model(good.mesh,p.x*16+good.width*8,0,p.y*16+good.depth*8) end
      if C.placement then local p=C.placement;local good=U.goods[p.id];g.setColor(1,1,1,.55);self:model(good.mesh,p.x*16+good.width*8,1,p.y*16+good.depth*8);g.setColor(1,1,1)end
    else
      local bx,by=math.floor(s.x/32),math.floor(s.y/32)
      local radius=math.ceil(160*zoom/.7/512)+1
      for dy=-radius,radius do for dx=-radius,radius do local x,y=bx+dx,by+dy
        if x>=0 and y>=0 and x<15 and y<15 then
          local id=U.map.ids[y*15+x+1]-561;self:model(string.format('ugmap%02dc',id),x*512+256,0,y*512+256)
        end
      end end
      for _,v in ipairs(U.vendors) do if math.abs(v.x-s.x)<14*zoom and math.abs(v.y-s.y)<18*zoom then
          local Ow=require('src.core.game3.ow_sprites');local spr=assert(Ow.getDraw(56),'FireRed Hiker sprite missing')
          local frame,flip=Ow.pose(spr,'down',false,false);self:actor(spr,frame,flip,v.x*16+8,v.y*16+8)
      end end
    end
    local c=not s.inBase and U.cynthia
    local visible=c and math.abs(c.x-s.x)<14*zoom and math.abs(c.y-s.y)<18*zoom
    local function drawCynthia()
      if visible then
        -- Keep her opaque, but sort by feet position against the player's
        -- interpolated position so walking across her row changes layering.
        local x,y=self:project(c.x,c.y,0)
        local face={down=1,left=2,right=3,up=4}
        g.setShader()
        g.setDepthMode('always',false)
        self:fieldSprite('npc/cynthia_faces.png',x,y,18/zoom,28/zoom,face[c.facing] or 1)
        g.setDepthMode('less',true)
        g.setShader(self.shader)
      end
    end
    if visible and py<c.y then
      self:player(C)
      drawCynthia()
    else
      drawCynthia()
      self:player(C)
    end
    g.setShader();g.setDepthMode();g.setColor(1,1,1)
    if not s.inBase then
      for key,p in pairs(s.spots) do if math.abs(p.x-s.x)<10*zoom and math.abs(p.y-s.y)<12*zoom then
        local x,y=self:project(p.x,p.y,16);local a=.45+.55*math.abs(math.sin(C.time*4+p.x));g.setColor(1,.85,.2,a)
        local k=math.max(.2,1/zoom)
        g.rectangle('fill',x-k,y-4*k,2*k,8*k);g.rectangle('fill',x-4*k,y-k,8*k,2*k);g.setColor(1,1,.85,a);g.rectangle('fill',x-k,y-k,2*k,2*k)
      end end
      if s.base then local x,y=self:project(s.base.x,s.base.y,4);g.setColor(.14,.09,.055);g.rectangle('fill',x-6/zoom,y-14/zoom,12/zoom,18/zoom);g.setColor(.9,.76,.35);g.rectangle('line',x-7/zoom,y-15/zoom,14/zoom,19/zoom) end
      if C.radar>0 then
        for _,p in pairs(s.buried) do local x,y=self:project(p.x,p.y,0);g.setColor(.3,.8,1,.8);g.circle('line',x,y,math.max(1,4/zoom)) end
      end
    end
    if C.placement then local p=C.placement;local x,y=self:project(p.x,p.y,0);local good=U.goods[p.id];g.setColor(.3,1,.5,.65);g.rectangle('line',x-8/zoom,y-6/zoom,16*good.width/zoom,11.2*good.depth/zoom) end
    g.setCanvas(self.canvas);g.origin();g.setColor(1,1,1);g.draw(self.world,0,0)
  end
  function R:box(x,y,w,h)
    g.setColor(.22,.16,.33,.97);g.rectangle('fill',x,y,w,h,3);g.setColor(.87,.83,.66);g.rectangle('line',x+.5,y+.5,w-1,h-1,3);g.setColor(1,1,1)
  end
  function R:text(text,x,y,w,small)
    g.setFont(small and self.small or self.font);g.setColor(.12,.1,.16);g.printf(text,x+1,y+1,w or 240);g.setColor(1,1,.95);g.printf(text,x,y,w or 240)
  end
  function R:mining(C)
    local m=C.mine;g.setColor(1,1,1);g.draw(self:image('mining/interface.png'),0,192)
    for _,o in ipairs(m.objects) do local d=U.mining_objects[o.id];g.setColor(1,1,1,o.recovered and .6 or 1);g.draw(self:image('mining/'..d.name..'.png'),o.x*16,224+o.y*16) end
    local dirt=self:image('mining/dirt_tiles.png');local offsets={[0]=112,80,64,48,32,16,0}
    for y=0,9 do for x=0,12 do local layer=m.layers[y*13+x+1]
      if layer>0 then local q=self.quads[layer];if not q then q=g.newQuad(offsets[layer],0,16,16,dirt:getDimensions());self.quads[layer]=q end
        g.setColor(1,1,1);g.draw(dirt,q,x*16,224+y*16)
      end
    end end
    g.setColor(1,1,1);g.rectangle('line',m.x*16+.5,224+m.y*16+.5,15,15)
    if C.swing and C.time-C.swing.start<.3 then local t=C.time-C.swing.start
      self:effect('animations',(C.swing.tool=='hammer' and 2 or 6)+math.min(3,math.floor(t*14)),C.swing.x*16+8,224+C.swing.y*16+8)
    end
    -- Crack growth is proportional to the same 196-point stability budget.
    g.setColor(.18,.12,.08);local len=(196-m.integrity)/196*205
    for x=0,len,6 do local y=200+((math.floor(x/6)%3)-1)*3;g.line(x,y,x+6,200+((math.floor(x/6+1)%3)-1)*3) end
    self:box(210,345,44,37);self:text(m.tool=='pick' and 'PICK' or 'HAMMER',213,348,40,true);self:text('B: swap',213,363,40,true)
    if m.complete then self:box(10,267,236,60);self:text(m.integrity<=0 and 'The wall collapsed!' or 'Everything was dug up!',20,275,215);self:text(m.found..' of '..m.total..' finds recovered.\nA: return to the Underground',20,293,215,true) end
  end
  function R:minimap(C)
    local s=U.s;local rx,ry=s.x,s.y
    if s.inBase then rx,ry=s.base.entranceX,s.base.entranceY end
    local im=self:image('ui/radar.png')
    self.mapQuad=self.mapQuad or g.newQuad(56,0,144,140,im:getDimensions())
    local x,y,k=176,4,60/144
    g.setColor(1,1,1,.48);g.draw(im,self.mapQuad,x,y,0,k,k)
    local function point(px,py)return x+(2+px/480*140)*k,y+(6+py/480*130)*k end
    local px,py=point(rx,ry)
    if C.radar>0 then
      for _,p in pairs(s.spots)do local sx,sy=point(p.x,p.y);g.setColor(1,.9,.2,.95);g.rectangle('fill',sx,sy,1,1)end
      g.setColor(1,.8,.2,C.radar/4);g.circle('line',px,py,(4-C.radar)*7)
    end
    g.setColor(.15,.06,.02,.9);g.circle('fill',px,py,2)
    g.setColor(1,.35,.15,1);g.rectangle('fill',math.floor(px),math.floor(py),2,2)
    g.setColor(1,1,1)
  end
  -- The original mining artwork is 256x192. Fit it uniformly into 240x160,
  -- retaining all 13x10 cells and exactly reversing this transform for clicks.
  function R:inputPoint(x,y,C)
    local px,py=(x-self.ox)/self.scale,(y-self.oy)/(self.scaleY or self.scale)
    if px<0 or px>=240 or py<0 or py>=160 then return end
    if C.mine then
      px=(px-40/3)/(5/6);py=py/(5/6)+192
      if px<0 or px>=256 then return end
    end
    return px,py
  end
  function R:draw(C,w,h)
    self:init();g.push('all');g.setCanvas(self.canvas);g.origin();g.clear(.03,.03,.05,1);g.setColor(1,1,1)
    local shop=C.exchange and C.exchange:isOpen()
    if C.mine then
      self.mineCanvas=self.mineCanvas or g.newCanvas(256,192);self.mineCanvas:setFilter('nearest','nearest')
      g.setCanvas(self.mineCanvas);g.clear();g.origin();g.translate(0,-192);self:mining(C)
      g.setCanvas(self.canvas);g.origin();g.setColor(1,1,1);g.draw(self.mineCanvas,40/3,0,0,5/6,5/6)
    else
      self:worldDraw(C)
      if not shop then self:minimap(C)end
    end
    if C.toast and C.toastTime>0 and not C.menu and not C.dialog and not shop then
      self:box(4,4,166,30);self:text(C.toast,9,8,156,true)
    end
    if C.placement then self:box(4,135,232,21);self:text('Move: position   A: place   B: cancel',9,141,222,true)end
    if C.menu then
      local m=C.menu;local first=math.max(1,m.index-6);local last=math.min(#m.rows,first+6)
      self:box(5,5,230,150);self:text(m.title,15,11,210)
      for i=first,last do local y=31+(i-first)*14
        if i==m.index then g.setColor(.43,.32,.56);g.rectangle('fill',11,y-1,218,14)end
        self:text((i==m.index and '> ' or '  ')..m.rows[i].label,15,y,210,true)
      end
      self:text('A: choose   B: back     '..m.index..'/'..#m.rows,15,141,210,true)
    end
    if C.dialog then
      local _,lines=self.font:getWrap(C.dialog.text,212)
      local height=math.min(150,math.max(58,#lines*self.font:getHeight()*self.font:getLineHeight()+30))
      local y=156-height;self:box(4,y,232,height);self:text(C.dialog.text,14,y+8,212);self:text('A / B: continue',14,143,212,true)
    end
    if shop then C.exchange:draw(self.world)end
    g.setCanvas();g.origin();g.setColor(.025,.025,.035);g.rectangle('fill',0,0,w,h)
    local Display=require('src.core.game3.display')
    local scale,ox,oy,_,_,sy=Display.fit(w,h)
    self.scale,self.scaleY,self.ox,self.oy=scale,sy or scale,ox,oy
    g.setColor(1,1,1);g.draw(self.canvas,ox,oy,0,scale,self.scaleY);g.pop()
  end
  return R
end
